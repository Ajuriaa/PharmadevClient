import React, { useContext, useEffect, useMemo, useReducer, useState } from "react";
import Navigation from "./src/components/navigation";

const App = () => {
    return (
        <Navigation/>
    );
}

export default App